<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => "Список пользователей из группы Администратор",
    "DESCRIPTION" => "Компонента выводит список пользователей из группы Администратор на страницу",
);