<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
    "NAME" => "Список товаров из раздела",
    "DESCRIPTION" => "Компонента выводит список товаров из выбранного раздела",
);